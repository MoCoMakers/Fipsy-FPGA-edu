﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDialog_ACCEL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDialog_ACCEL))
    Me.AccelPollTimer = New System.Windows.Forms.Timer(Me.components)
    Me.Group_Device_Description = New System.Windows.Forms.GroupBox()
    Me.Label16 = New System.Windows.Forms.Label()
    Me.Label10 = New System.Windows.Forms.Label()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Group_Device_Controls = New System.Windows.Forms.GroupBox()
    Me.Label14 = New System.Windows.Forms.Label()
    Me.Label12 = New System.Windows.Forms.Label()
    Me.Label15 = New System.Windows.Forms.Label()
    Me.LED_AccelZ = New System.Windows.Forms.Label()
    Me.LED_AccelY = New System.Windows.Forms.Label()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.LED_DevicePowerState = New System.Windows.Forms.Label()
    Me.LED_AccelX = New System.Windows.Forms.Label()
    Me.Label9 = New System.Windows.Forms.Label()
    Me.LED_DeviceID = New System.Windows.Forms.Label()
    Me.Label7 = New System.Windows.Forms.Label()
    Me.Group_Device_Description.SuspendLayout()
    Me.Group_Device_Controls.SuspendLayout()
    Me.SuspendLayout()
    '
    'AccelPollTimer
    '
    Me.AccelPollTimer.Interval = 1000
    '
    'Group_Device_Description
    '
    Me.Group_Device_Description.Controls.Add(Me.Label16)
    Me.Group_Device_Description.Controls.Add(Me.Label10)
    Me.Group_Device_Description.Controls.Add(Me.Label5)
    Me.Group_Device_Description.Controls.Add(Me.Label4)
    Me.Group_Device_Description.Controls.Add(Me.Label3)
    Me.Group_Device_Description.Controls.Add(Me.Label2)
    Me.Group_Device_Description.Controls.Add(Me.Label1)
    Me.Group_Device_Description.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Group_Device_Description.ForeColor = System.Drawing.Color.Aqua
    Me.Group_Device_Description.Location = New System.Drawing.Point(12, 12)
    Me.Group_Device_Description.Name = "Group_Device_Description"
    Me.Group_Device_Description.Size = New System.Drawing.Size(570, 155)
    Me.Group_Device_Description.TabIndex = 144
    Me.Group_Device_Description.TabStop = False
    Me.Group_Device_Description.Text = "Device Description"
    '
    'Label16
    '
    Me.Label16.AutoSize = True
    Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label16.ForeColor = System.Drawing.Color.Yellow
    Me.Label16.Location = New System.Drawing.Point(21, 124)
    Me.Label16.Name = "Label16"
    Me.Label16.Size = New System.Drawing.Size(392, 16)
    Me.Label16.TabIndex = 148
    Me.Label16.Text = "-> This demonstration for desktop use is limited to the +/-2g range"
    '
    'Label10
    '
    Me.Label10.AutoSize = True
    Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label10.ForeColor = System.Drawing.Color.Yellow
    Me.Label10.Location = New System.Drawing.Point(21, 108)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(483, 16)
    Me.Label10.TabIndex = 147
    Me.Label10.Text = "-> The additional ADC inputs and many other features are not demonstrated here"
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label5.ForeColor = System.Drawing.Color.Yellow
    Me.Label5.Location = New System.Drawing.Point(21, 92)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(451, 16)
    Me.Label5.TabIndex = 146
    Me.Label5.Text = "-> This dialog demonstrates use of the Backhauler PMOD SPI configuration"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label4.ForeColor = System.Drawing.Color.Yellow
    Me.Label4.Location = New System.Drawing.Point(21, 60)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(259, 16)
    Me.Label4.TabIndex = 145
    Me.Label4.Text = "-> The PMOD interface configuration is SPI"
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label3.ForeColor = System.Drawing.Color.Yellow
    Me.Label3.Location = New System.Drawing.Point(21, 76)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(389, 16)
    Me.Label3.TabIndex = 144
    Me.Label3.Text = "-> The peripheral provides an LIS3DH 3-axis accelerometer chip"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label2.ForeColor = System.Drawing.Color.Yellow
    Me.Label2.Location = New System.Drawing.Point(21, 44)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(455, 16)
    Me.Label2.TabIndex = 143
    Me.Label2.Text = "-> Manufacturer part number or identifier for this peripheral is AP1606-ACCEL"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.ForeColor = System.Drawing.Color.Yellow
    Me.Label1.Location = New System.Drawing.Point(21, 28)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(357, 16)
    Me.Label1.TabIndex = 142
    Me.Label1.Text = "-> Peripheral manufacturer is Allied Component Works, LLC"
    '
    'Group_Device_Controls
    '
    Me.Group_Device_Controls.Controls.Add(Me.Label14)
    Me.Group_Device_Controls.Controls.Add(Me.Label12)
    Me.Group_Device_Controls.Controls.Add(Me.Label15)
    Me.Group_Device_Controls.Controls.Add(Me.LED_AccelZ)
    Me.Group_Device_Controls.Controls.Add(Me.LED_AccelY)
    Me.Group_Device_Controls.Controls.Add(Me.Label6)
    Me.Group_Device_Controls.Controls.Add(Me.LED_DevicePowerState)
    Me.Group_Device_Controls.Controls.Add(Me.LED_AccelX)
    Me.Group_Device_Controls.Controls.Add(Me.Label9)
    Me.Group_Device_Controls.Controls.Add(Me.LED_DeviceID)
    Me.Group_Device_Controls.Controls.Add(Me.Label7)
    Me.Group_Device_Controls.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Group_Device_Controls.ForeColor = System.Drawing.Color.Aqua
    Me.Group_Device_Controls.Location = New System.Drawing.Point(12, 173)
    Me.Group_Device_Controls.Name = "Group_Device_Controls"
    Me.Group_Device_Controls.Size = New System.Drawing.Size(570, 208)
    Me.Group_Device_Controls.TabIndex = 149
    Me.Group_Device_Controls.TabStop = False
    Me.Group_Device_Controls.Text = "Device Controls"
    '
    'Label14
    '
    Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label14.ForeColor = System.Drawing.Color.Yellow
    Me.Label14.Location = New System.Drawing.Point(342, 94)
    Me.Label14.Name = "Label14"
    Me.Label14.Size = New System.Drawing.Size(76, 16)
    Me.Label14.TabIndex = 166
    Me.Label14.Text = "Z"
    Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'Label12
    '
    Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label12.ForeColor = System.Drawing.Color.Yellow
    Me.Label12.Location = New System.Drawing.Point(253, 94)
    Me.Label12.Name = "Label12"
    Me.Label12.Size = New System.Drawing.Size(78, 16)
    Me.Label12.TabIndex = 165
    Me.Label12.Text = "Y"
    Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'Label15
    '
    Me.Label15.AutoSize = True
    Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label15.ForeColor = System.Drawing.Color.Yellow
    Me.Label15.Location = New System.Drawing.Point(160, 78)
    Me.Label15.Name = "Label15"
    Me.Label15.Size = New System.Drawing.Size(102, 16)
    Me.Label15.TabIndex = 164
    Me.Label15.Text = "Acceleration (g)"
    '
    'LED_AccelZ
    '
    Me.LED_AccelZ.BackColor = System.Drawing.Color.Gray
    Me.LED_AccelZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.LED_AccelZ.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LED_AccelZ.ForeColor = System.Drawing.Color.Lime
    Me.LED_AccelZ.Location = New System.Drawing.Point(337, 110)
    Me.LED_AccelZ.Name = "LED_AccelZ"
    Me.LED_AccelZ.Size = New System.Drawing.Size(81, 26)
    Me.LED_AccelZ.TabIndex = 163
    Me.LED_AccelZ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'LED_AccelY
    '
    Me.LED_AccelY.BackColor = System.Drawing.Color.Gray
    Me.LED_AccelY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.LED_AccelY.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LED_AccelY.ForeColor = System.Drawing.Color.Lime
    Me.LED_AccelY.Location = New System.Drawing.Point(250, 110)
    Me.LED_AccelY.Name = "LED_AccelY"
    Me.LED_AccelY.Size = New System.Drawing.Size(81, 26)
    Me.LED_AccelY.TabIndex = 161
    Me.LED_AccelY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'Label6
    '
    Me.Label6.AutoSize = True
    Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label6.ForeColor = System.Drawing.Color.Yellow
    Me.Label6.Location = New System.Drawing.Point(160, 148)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(126, 16)
    Me.Label6.TabIndex = 159
    Me.Label6.Text = "Device Power State"
    '
    'LED_DevicePowerState
    '
    Me.LED_DevicePowerState.BackColor = System.Drawing.Color.Gray
    Me.LED_DevicePowerState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.LED_DevicePowerState.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LED_DevicePowerState.ForeColor = System.Drawing.Color.Lime
    Me.LED_DevicePowerState.Location = New System.Drawing.Point(163, 164)
    Me.LED_DevicePowerState.Name = "LED_DevicePowerState"
    Me.LED_DevicePowerState.Size = New System.Drawing.Size(255, 26)
    Me.LED_DevicePowerState.TabIndex = 158
    Me.LED_DevicePowerState.Text = "POWER DOWN"
    Me.LED_DevicePowerState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'LED_AccelX
    '
    Me.LED_AccelX.BackColor = System.Drawing.Color.Gray
    Me.LED_AccelX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.LED_AccelX.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LED_AccelX.ForeColor = System.Drawing.Color.Lime
    Me.LED_AccelX.Location = New System.Drawing.Point(163, 110)
    Me.LED_AccelX.Name = "LED_AccelX"
    Me.LED_AccelX.Size = New System.Drawing.Size(81, 26)
    Me.LED_AccelX.TabIndex = 157
    Me.LED_AccelX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'Label9
    '
    Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label9.ForeColor = System.Drawing.Color.Yellow
    Me.Label9.Location = New System.Drawing.Point(163, 94)
    Me.Label9.Name = "Label9"
    Me.Label9.Size = New System.Drawing.Size(81, 16)
    Me.Label9.TabIndex = 156
    Me.Label9.Text = "X"
    Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'LED_DeviceID
    '
    Me.LED_DeviceID.BackColor = System.Drawing.Color.Gray
    Me.LED_DeviceID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.LED_DeviceID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LED_DeviceID.ForeColor = System.Drawing.Color.Lime
    Me.LED_DeviceID.Location = New System.Drawing.Point(163, 42)
    Me.LED_DeviceID.Name = "LED_DeviceID"
    Me.LED_DeviceID.Size = New System.Drawing.Size(255, 26)
    Me.LED_DeviceID.TabIndex = 155
    Me.LED_DeviceID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'Label7
    '
    Me.Label7.AutoSize = True
    Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label7.ForeColor = System.Drawing.Color.Yellow
    Me.Label7.Location = New System.Drawing.Point(160, 26)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(231, 16)
    Me.Label7.TabIndex = 150
    Me.Label7.Text = "Device ID (Should be 33 if connected)"
    '
    'frmDialog_ACCEL
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.BackColor = System.Drawing.Color.DimGray
    Me.CausesValidation = False
    Me.ClientSize = New System.Drawing.Size(595, 394)
    Me.Controls.Add(Me.Group_Device_Controls)
    Me.Controls.Add(Me.Group_Device_Description)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "frmDialog_ACCEL"
    Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
    Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
    Me.Text = "Dialog For ACW 3-Axis Accelerometer"
    Me.Group_Device_Description.ResumeLayout(False)
    Me.Group_Device_Description.PerformLayout()
    Me.Group_Device_Controls.ResumeLayout(False)
    Me.Group_Device_Controls.PerformLayout()
    Me.ResumeLayout(False)

End Sub
    Friend WithEvents AccelPollTimer As System.Windows.Forms.Timer
    Friend WithEvents Group_Device_Description As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Group_Device_Controls As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LED_DeviceID As System.Windows.Forms.Label
    Friend WithEvents LED_AccelX As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LED_DevicePowerState As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents LED_AccelZ As System.Windows.Forms.Label
    Friend WithEvents LED_AccelY As System.Windows.Forms.Label

End Class
