﻿Module BhPmodMakeFPGA

'---------------------------------------------------------------------------------------
'API functions as defined in DLL 
'---------------------------------------------------------------------------------------

' General utility functions - always valid
Declare Function MakeFPGA_Open Lib "BhPmodMakeFPGA.dll" () As UInteger
Declare Function MakeFPGA_Close Lib "BhPmodMakeFPGA.dll" () As UInteger

' Discrete I/O functions - valid in any configuration within limitations
Declare Function MakeFPGA_ReadDeviceID Lib "BhPmodMakeFPGA.dll" (ByRef aDeviceID As Byte) As UInteger
Declare Function MakeFPGA_ReadUniqueID Lib "BhPmodMakeFPGA.dll" (ByRef aUniqueID As Byte) As UInteger
Declare Function MakeFPGA_EraseAll Lib "BhPmodMakeFPGA.dll" () As UInteger
Declare Function MakeFPGA_LoadConfiguration Lib "BhPmodMakeFPGA.dll" () As UInteger
Declare Function MakeFPGA_WriteFeatures Lib "BhPmodMakeFPGA.dll" (ByRef aFeatureRow As Byte, ByRef aFeabits As Byte) As UInteger
Declare Function MakeFPGA_WriteConfiguration Lib "BhPmodMakeFPGA.dll" (ByVal aJEDECFileName As String) As UInteger

'---------------------------------------------------------------------------------------
'Defined values related to library calls
'---------------------------------------------------------------------------------------


'---------------------------------------------------------------------------------------
'End of module
'---------------------------------------------------------------------------------------

End Module
