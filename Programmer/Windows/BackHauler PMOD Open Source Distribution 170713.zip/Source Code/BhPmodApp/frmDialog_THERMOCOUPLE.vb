﻿'---------------------------------------------------------------------------------------
'frmDialog_THERMOCOUPLE.VB
'
'This is a dialog form for a specific PMOD peripheral.
'
'---------------------------------------------------------------------------------------

Public Class frmDialog_THERMOCOUPLE

'---------------------------------------------------------------------------------------
'Local Public Variables (Application Private)
'---------------------------------------------------------------------------------------

'The I2C device address can be changed here
'This is the default as matches the default wiring of the peripheral
'Private so it applies only to this class and other private uses of this identifier are allowed
Private Const I2C_DEVICE_ADDRESS As Byte = &H60&

'---------------------------------------------------------------------------------------
'Module Entry And Exit Functions
'---------------------------------------------------------------------------------------
 
Private Sub frmDialog_THERMOCOUPLE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
 'Configure the PMOD connector
 PresentConfiguration = PMOD_CONFIGURATION_I2C
 SetPresentConfiguration()
 DisplayPresentConfiguration()
 'It is not clear that this device starts in power down state (appears it does not)
 'So set it to power down to agree with the display 
 'This call will do that if the 'LED' box is initially blank
 LED_DevicePowerState_Click(sender, e)
 'Start looking for temperature sensor data
 TempPollTimer.Enabled = True
End Sub

Private Sub frmDialog_THERMOCOUPLE_UnLoad(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.FormClosing
 'Stop polling for data
 TempPollTimer.Enabled = False
 'Remove the configuration 
 ConfigurePassive()
End Sub

'---------------------------------------------------------------------------------------
'Handler For Polling Timer
'---------------------------------------------------------------------------------------

Private Sub TempPollTimer_Tick(sender As Object, e As EventArgs) Handles TempPollTimer.Tick
 Dim temp(4) As Byte
 Dim id(2) As Byte
 Dim stemperature As Short
 Dim ftemperature As Double
 Dim datacnt As Byte

 'The poll timer fires every second as temperature changes only just so fast

 'Driver or concept errors just show as error in a benign way
 On Error GoTo TPT_ERREXIT

 'Get the device ID and revision (starting at subaddress 20H) to be sure we are connected to the right device
 'Note that VB creates variables for the constants in the ByRef items, while other languages might not allow this
 'Note that the MCP9600 device seems to not handle restart well, so we opt to send the subaddress ahead
 id(0) = 0
 datacnt = 2
 If (BHPMOD_I2C_Read(I2C_DEVICE_ADDRESS, 1, &H20&, datacnt, id(0)) <> 1) Then GoTo TPT_ERREXIT
 If (datacnt <> 2) Then GoTo TPT_ERREXIT
 'Show what we got as an ID
 LED_DeviceID.ForeColor = LED_COLOR_STATUS_GOOD
 LED_DeviceID.Text = LngToHexByte(id(0))
 'See if we have the right ID, and if not caution the user and show error on temperature and leave
 If (id(0) <> &H40&) Then
  LED_Revision.Text = "--.--"
  GoTo TPT_ERREXIT
 End If
 'Show revision that goes with the above device id
 LED_Revision.ForeColor = LED_COLOR_STATUS_GOOD
 LED_Revision.Text = Trim(Str(id(1) \ 16)) + "." + Trim(Str(id(1) Mod 16))

 'If the device is powered down, show indeterminate state and leave
 If (LED_DevicePowerState.Text <> "ACTIVE") Then
  LED_HotJunctionTemperature.Text = "----"
  LED_HotJunctionTemperature.ForeColor = LED_COLOR_STATUS_ON
  LED_ColdJunctionTemperature.Text = "----"
  LED_ColdJunctionTemperature.ForeColor = LED_COLOR_STATUS_ON
  Exit Sub
 End If

 'Get the hot junction temperature  
 datacnt = 2
 If (BHPMOD_I2C_Read(I2C_DEVICE_ADDRESS, 1, 0, datacnt, temp(1)) <> 1) Then GoTo TPT_ERREXIT
 If (datacnt <> 2) Then GoTo TPT_ERREXIT
 'Marshal bytes - device reports big endian, and the PC is little endian
 temp(0) = temp(2)
 stemperature = BitConverter.ToInt16(temp, 0)
 'Convert to float and scale to resolution
 ftemperature = stemperature
 ftemperature *= 0.0625
 'Display to the implied resolution (not accuracy, which would be more course)
 LED_HotJunctionTemperature.Text = Format(ftemperature, "0.0")
 LED_HotJunctionTemperature.ForeColor = LED_COLOR_STATUS_GOOD

 'Get the cold junction temperature  
 datacnt = 2
 If (BHPMOD_I2C_Read(I2C_DEVICE_ADDRESS, 1, 2, datacnt, temp(1)) <> 1) Then GoTo TPT_ERREXIT
 If (datacnt <> 2) Then GoTo TPT_ERREXIT
 'Marshal bytes - device reports big endian, and the PC is little endian
 temp(0) = temp(2)
 stemperature = BitConverter.ToInt16(temp, 0)
 'Convert to float and scale to resolution
 'Cold junction value is only 12 bits, but the part sign extends it so we can treat it as 16 bits
 ftemperature = stemperature
 ftemperature *= 0.0625
 'Display to the implied resolution (not accuracy, which would be more course)
 LED_ColdJunctionTemperature.Text = Format(ftemperature, "0.0")
 LED_ColdJunctionTemperature.ForeColor = LED_COLOR_STATUS_GOOD

 'Normal exit
 Exit Sub

 'Problems get us here
TPT_ERREXIT:
 LED_DeviceID.ForeColor = LED_COLOR_STATUS_ON
 LED_Revision.ForeColor = LED_COLOR_STATUS_ON
 LED_HotJunctionTemperature.Text = "ERROR"
 LED_HotJunctionTemperature.ForeColor = LED_COLOR_STATUS_BAD
 LED_ColdJunctionTemperature.Text = "ERROR"
 LED_ColdJunctionTemperature.ForeColor = LED_COLOR_STATUS_BAD
 LED_DevicePowerState.Text = "DEVICE ERROR"
 LED_DevicePowerState.ForeColor = LED_COLOR_STATUS_ON
End Sub

'---------------------------------------------------------------------------------------
'Handlers For User Controls
'---------------------------------------------------------------------------------------

Private Sub LED_DevicePowerState_Click(sender As Object, e As EventArgs) Handles LED_DevicePowerState.Click
 Dim datacnt As Byte
 Dim regdata As Byte

 'If we are in power down, try to go to active 
 If (LED_DevicePowerState.Text = "POWER DOWN") Then
  'Sensor configuration set to 03H for K-type, some filtering
  datacnt = 1
  regdata = 3
  If (BHPMOD_I2C_Write(I2C_DEVICE_ADDRESS, 1, 5, datacnt, regdata) <> 1) Then Exit Sub
  If (datacnt <> 1) Then Exit Sub
  'Device configuration register set to 00H for slow, power hungry, full resolution, normal mode
  datacnt = 1
  regdata = 0
  If (BHPMOD_I2C_Write(I2C_DEVICE_ADDRESS, 1, 6, datacnt, regdata) <> 1) Then Exit Sub
  If (datacnt <> 1) Then Exit Sub
  'If all appears successful show running, allowing the timer to actually read and interpret data
  LED_DevicePowerState.ForeColor = LED_COLOR_STATUS_GOOD
  LED_DevicePowerState.Text = "ACTIVE"
  Exit Sub
 End If

 'We are not in power down, so it must be we want to go to power down
 'If we are in some error state, this would be the right thing to try on click anyway
 'If this fails, just leave here and let the timer put us in that error state
 'Device configuration register set to 01H for power down
 datacnt = 1
 regdata = 1
 LED_DevicePowerState.Text = "ERROR"
 If (BHPMOD_I2C_Write(I2C_DEVICE_ADDRESS, 1, 6, datacnt, regdata) <> 1) Then Exit Sub
 If (datacnt <> 1) Then Exit Sub
 'Show shutdown - but if there was an error even a blank display would tell timer to stop reading data
 LED_DevicePowerState.ForeColor = LED_COLOR_STATUS_GOOD
 LED_DevicePowerState.Text = "POWER DOWN"
End Sub

End Class