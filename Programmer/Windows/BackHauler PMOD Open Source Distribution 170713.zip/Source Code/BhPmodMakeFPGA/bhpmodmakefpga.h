/* BHPMODMAKEFPGA.H                                                              

   Header file for MakeFPGA loader library.

*/

// This definition allows this header file to be used for export and import.
// Export names are defined in a .def file to be equivalent to the names 
// defined in this header file and not mangled.  Include the .lib file
// with the source files to link with a C project.
#define DCAPI extern "C" DWORD WINAPI

/*---------------------------------------------------------------------------*/
/* API Exports                                                               */
/*---------------------------------------------------------------------------*/

DCAPI MakeFPGA_Open(void);
DCAPI MakeFPGA_Close(void);
DCAPI MakeFPGA_ReadDeviceID(BYTE *DeviceID);
DCAPI MakeFPGA_ReadUniqueID(BYTE *UniqueID);
DCAPI MakeFPGA_EraseAll(void);
DCAPI MakeFPGA_LoadConfiguration(void);
DCAPI MakeFPGA_WriteFeatures(BYTE *FeatureRow, BYTE *Feabits);
DCAPI MakeFPGA_WriteConfiguration(char *JEDECFileName);

/*--------------------------------------------------------------------------*/

/* End of header file */

