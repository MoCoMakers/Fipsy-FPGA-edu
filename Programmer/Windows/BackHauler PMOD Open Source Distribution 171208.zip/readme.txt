The BackHauler PMOD project team has included a copy of the SiLabs USB Express drivers from the USB Express SDK materials freely 
available from the Silicon Labs website in order to present a complete image of what we used to compile and test the associated code.  
It might be advisable to visit www.silabs.com to locate the latest USB Express SDK.  Historically, newer versions have required a 
driver update, replacement of libraries and header files in the code base, and a recompile, but little else.

The prescribed way to install the environment is to either install the USB SDK and/or the drivers only, using the appropriate
installer in the drivers folder, and then plug in the BackHauler USB.  The BackHauler USB will be identified as a USB Express 
device. That is, it is equivalent to a Silicon Labs development kit in this respect, with the same USB device codes and so on, 
and it is in fact similar to such a device.  Silicon Labs has excellent instructions for paths to custom product variations, 
but those steps did not seem appropriate to the present task where all aspects should remain open and fluid.  

The libraries and header files associated with this version of the USB SDK are already located with the source code and executable 
files where they are needed.  The firmware is built as a Kiel MicroVision project (Silicon Labs version available through the 
Silicon Labs website).  The rest of the software is a Microsoft Visual Studio 2012 solution.  

If a different environment is used for any aspect of your own application, then compiled components should still be usable.  
For example, the API DLL should be callable from LabView, and the firmware on the BackHauler USB should not need changing 
for most users.  The open source code leaves little doubt about what these components do or what they need to accomplish 
those tasks.  If those components are being used without recompiling in Visual Studio (of any version), then it will 
probably be necessary to run the application installer in order to install all compiler specific libraries on which 
the API depends, such as C runtime libraries.  This installer does not install the drivers.

All that said, it is still a primary assumption that most users of this product are .NET developers who will port the 
source code to their own preferred version of Visual Studio.  Even if the choice of language is to be changed (for example,
to use C# instead of Visual Basic) the source code should be useful to understand the principles.  

